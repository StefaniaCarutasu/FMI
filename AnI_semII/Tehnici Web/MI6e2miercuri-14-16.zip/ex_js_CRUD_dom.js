function randInt(a,b){ //[a, b)
	return Math.floor(a+(b-a)*Math.random());//Math.random() -> [0,1)
}


var vPrenume=["Costica", "Gigel", "Dorel", "Maricica", "Dorica", "Gigileana", "Crinisoara", "Zoe", "Gogu", "Bob"];
var vPrefixeNume=["Bubul", "Bondar", "Dudul", "Gogul", "Zumzul"];
var vSufixeNume=["ache", "escu", "esteanu","eanu", "eschi"];
var grupe=["A", "B", "C", "D"];


function noteRandom(){
	var nrNote=randInt(1,5);
	var note=[];
	for(let i=0;i<nrNote;i++)
	{ 
		note.push(randInt(1,11));
	}
	return note;
}


function elevRandom(){
	return {
		prenume: vPrenume[randInt(0, vPrenume.length)],
		nume: vPrefixeNume[randInt(0, vPrefixeNume.length)]+vSufixeNume[randInt(0, vSufixeNume.length)],
		grupa: grupe[randInt(0, grupe.length)],
		note: noteRandom()
	};
}
function genereazaElevi(n){
	var elevi=[];
	for(let i=0;i<n;i++){
		elevi.push(elevRandom());//adauga elev random la finalul vectorului
	}
	console.log(elevi);
	return elevi;
}

function creeazaRand(tipCelula, vector){
	tr=document.createElement("tr"); //TO DO sa se creeze un rand
	/*
  for(let i=0; i<vector.length; i++){
    x = vector[i];
  }

  */
  for(let x of vector){
		var celula=document.createElement(tipCelula);// creez <th> sau <td>
		celula.innerHTML = x; //TO DO continutul celulei trebuie sa fie valoarea din vector
		tr.appendChild(celula);// TO DO adaugati celula in rand
		if(tipCelula=="td"){

      //<td class="c1 c2 c3 c4"
			tr.classList.add(vector[2]);//clasa sa fie egala cu grupa elevului
			
			tr.onclick=function(e){ // e - datele evenimentului(Event)
        //ctrlKey, shiftKey, altKey
        if(e.ctrlKey){ //true cand ctrl e apasat
          this.remove();
          //this.children[1] e td-ul cu numele
          afisLog("elevul "+ this.children[1].innerHTML+" "+ this.children[0].innerHTML +" a fost sters");
        }
        else{
          //toggle - daca exista clasa, o sa o stearga, daca nu, o sa o adauge
          this.classList.toggle("selectat");
        }
			}
		}
	}
	return tr;
}

function creeazaTabel(elevi){
	if(!elevi || elevi.length==0) return;
	
	var tabel=document.createElement("table");// <table></table>
	tabel.id="tab";//<table id="tab"></table>
	var thead=document.createElement("thead");// TO DO - creare thead <thead></thead>
  // TO DO - adugare thead in tabel
  tabel.appendChild(thead);//<table id="tab"><thead></thead></table>
	
	var rand=creeazaRand("th",Object.keys(elevi[0]));// <tr><th>nume</th><th>prenume</th>......
  //Object.keys(elevi[0]) -> ["nume","prenume", "grupa", "note"]
	console.log("Proprietati:");console.log(Object.keys(elevi[0]));
	thead.appendChild(rand);
		
	
	var tbody=document.createElement("tbody");
	tabel.appendChild(tbody);
	for(let elev of elevi){ //TO DO vrem ca variabila elev sa aiba pe rand ca valoare fiecare element din elevi
		rand=creeazaRand("td",Object.values(elev));//<tr><td></td>
		console.log("Valori:");console.log(Object.values(elev));
		tbody.appendChild(rand);

	}
	return tabel;
}

contor=0;
function afisLog(sir){
  var info=document.getElementById("info");
  var par=document.createElement("p");
  par.innerHTML="["+ new Date() +"] " + sir;
  info.appendChild(par);
  contor++;
  info.title=contor;
}


//<body onload="f()">
window.onload=function(){
	var v_elevi=genereazaElevi(10);
	document.getElementById("container_tabel").appendChild(creeazaTabel(v_elevi));// <table>
}